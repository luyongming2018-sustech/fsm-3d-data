pscube <vp3.bin  n1=301 n2=301 n3=301 d1=1 d2=1 d3=1 label1="Depth (km)" label2="X (km)" label3="Y (km)"  >vp1.eps
pscube <delta3.bin  n1=301 n2=301 n3=301 d1=1 d2=1 d3=1 label1="Depth (km)" label2="X (km)" label3="Y (km)"  >d3.eps
pscube <epsilon3.bin  n1=301 n2=301 n3=301 d1=1 d2=1 d3=1 label1="Depth (km)" label2="X (km)" label3="Y (km)"  >e3.eps
